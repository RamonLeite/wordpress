<?php

	date_default_timezone_set('America/Sao_Paulo');

	require_once "bd/bd.php";
	require_once "classes/administrador.php";

?>