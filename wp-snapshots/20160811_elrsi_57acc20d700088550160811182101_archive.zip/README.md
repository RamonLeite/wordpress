Para usar o sistema:

A maneira mais fácil é clonando o repositório.
Para tal, basta entrar na pasta raiz do apache (c:xampp/htdocs/ ou /var/www/html) e executar o comando:

git clone https://github.com/ricardomelogon/wordpress.git

Os arquivos serão automáticamente baixados e será criada uma pasta chamada "wordpress", onde ficarão os arquivos do projeto.

Deverá ser criado um BD com o nome 'elrsi', que deverá estão na codificação: (Versão mais recente do Xampp)

Character ser: utf8mb4 -- UTF-8 Unicode

Collation: utf8mb4_general_ci

Após criar o BD, executar o arquivo elrsi.sql que está na base de dados, então todas as informações estarão registradas.
